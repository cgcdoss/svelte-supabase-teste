import{a as t}from"../chunks/entry.9InUTt77.js";export{t as start};
